﻿// log4net configuration file
[assembly: log4net.Config.XmlConfigurator(ConfigFile = @"iToolLog.xml", Watch = true)]