﻿namespace helloCsDotNetFW
{
    partial class frmMain
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEND = new System.Windows.Forms.Button();
            this.lblMESSAGE = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnEND
            // 
            this.btnEND.Location = new System.Drawing.Point(354, 382);
            this.btnEND.Name = "btnEND";
            this.btnEND.Size = new System.Drawing.Size(75, 23);
            this.btnEND.TabIndex = 0;
            this.btnEND.Text = "END";
            this.btnEND.UseVisualStyleBackColor = true;
            this.btnEND.Click += new System.EventHandler(this.btnEND_Click_1);
            // 
            // lblMESSAGE
            // 
            this.lblMESSAGE.AutoSize = true;
            this.lblMESSAGE.Location = new System.Drawing.Point(64, 28);
            this.lblMESSAGE.Name = "lblMESSAGE";
            this.lblMESSAGE.Size = new System.Drawing.Size(35, 12);
            this.lblMESSAGE.TabIndex = 1;
            this.lblMESSAGE.Text = "Hello .NET framework.";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblMESSAGE);
            this.Controls.Add(this.btnEND);
            this.Name = "frmMain";
            this.Text = "Main";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEND;
        private System.Windows.Forms.Label lblMESSAGE;
    }
}

