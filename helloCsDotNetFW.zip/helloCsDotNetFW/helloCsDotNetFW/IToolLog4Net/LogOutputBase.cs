﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Reflection;

namespace ITool.Log4Net
{
    abstract class LogOutputBase
    {
        protected const String LK_METHOD_START = "MDS";
        protected const String LK_METHOD_END = "MDE";
        protected const String LK_THEN_START = "TNS";
        protected const String LK_ELSE_START = "ELS";
        protected const String LK_CYCLE_START = "CYS";
        protected const String LK_CASE_START = "CSS";
        protected const String LK_TRY_START = "TYS";
        protected const String LK_CATCH_START = "CTS";
        protected const String LK_FINALLY_START = "FNS";
        protected const String LK_EXCEPTION_CATCHED = "EXP";


        //private List<CallCommandInfo> callInfoList = new List<CallCommandInfo>();
        //internal Stack<CalledMethodInfo> CalledMethodStack = new Stack<CalledMethodInfo>();

        //Call information of all thread, key is threadId
        private Dictionary<String, CallDataHolder> threadCallData = new Dictionary<String, CallDataHolder>();

        internal long SeqNo = 1;

        ///Write version information to log file.
        internal abstract void writeVersion(String version);

        ///Process for Method-Start log.
        internal virtual void MethodStart(String threadId, String moduleName, String methodName, int lineNumOrg, int charNumOrg)
        {
            CallDataHolder callData = GetThreadCallData(threadId);

            //String[][] methodInfo = getCallerMethodInfo();
            //String mi = (methodInfo[1]==null?"":methodInfo[1][1]) + "," + methodInfo[0][0];
            SMethod sMethod = new SMethod(moduleName, methodName, lineNumOrg, charNumOrg);

            CalledMethodInfo calledMethod = null;
            CallCommandInfo ci = LocateCallInfoByCalledMethod(callData.CallCommandList, sMethod);
            if (ci != null)
            {
                //there is callInfo for this method
                calledMethod = new CalledMethodInfo(sMethod, ci.CallerMethod, ci.CallHappenLineNum, ci.CallHappenCharNum);
            }
            else
            {
                //parent is in excluded range, or current method is first method, or called in constructor block
                ci = StackTracer.TrackCallerModule(moduleName, methodName);
                if (ci != null)
                {
                    //called in constructor block
                    calledMethod = new CalledMethodInfo(sMethod, ci.CallerMethod, ci.CallHappenLineNum, ci.CallHappenCharNum);
                }
                else
                {
                    //parent is in excluded range, or current method is first method, or called in constructor block
                    calledMethod = new CalledMethodInfo(sMethod, null, 0, 0);
                }
            }
            callData.CalledMethodStack.Push(calledMethod);

        }

        ///Process for Method-End log.
        internal virtual void MethodEnd(String threadId, String moduleName, String methodName, int lineNumOrg, int charNumOrg)
        {
            CallDataHolder callData = GetThreadCallData(threadId);
            ClearCallInfo(callData.CallCommandList, callData.CalledMethodStack.Count);
            callData.CalledMethodStack.Pop();
        }

        ///Process for Then-Start log.
        internal abstract void ThenStart(String threadId, int lineNumOrg, int charNumOrg);

        ///Process for Else-Start log.
        internal abstract void ElseStart(String threadId, int lineNumOrg, int charNumOrg);

        ///Process for Cycle-Start log.
        internal abstract void CycleStart(String threadId, int lineNumOrg, int charNumOrg);

        ///Process for Case-Start log.
        internal abstract void CaseStart(String threadId, int lineNumOrg, int charNumOrg);

        ///Process for Try-Start log.
        internal abstract void TryStart(String threadId, int lineNumOrg, int charNumOrg);

        ///Process for Catch-Start log.
        internal abstract void CatchStart(String threadId, int lineNumOrg, int charNumOrg);

        ///Process for Finally-Start log.
        internal abstract void FinallyStart(String threadId, int lineNumOrg, int charNumOrg);

        /// <summary>
        /// Process for Exception-Catched log.
        /// </summary>
        /// <param name="threadId"></param>
        /// <param name="forAppTry">True means in the extra catch for whole method.
        /// In that case, if a EXP log for the exception has been created, the process will be ignored. 
        /// Otherwise EXP log will be created even duplicated, because case like two-level Try-Catch 
        /// will need two EXP log for matching different Try.
        /// </param>
        /// <param name="lineNumOrg"></param>
        /// <param name="charNumOrg"></param>
        internal abstract void ExceptionCatched(String threadId, bool forAppTry, int lineNumOrg, int charNumOrg);

        ///Add callInfo before a call happens.
        internal void BeforeCall(String threadId, int lineNumOrg, int charNumOrg,
                String calledModuleName, String calledMethodName,
                int calledMethodLineNum, int calledMethodCharNum)
        {
            CallDataHolder callData = GetThreadCallData(threadId);
            SMethod currentMethod = callData.CalledMethodStack.Peek().CalledMethod;
            SMethod calledMethod = new SMethod(calledModuleName, calledMethodName, calledMethodLineNum, calledMethodCharNum);
            callData.CallCommandList.Add(
                    new CallCommandInfo(currentMethod, lineNumOrg, charNumOrg, calledMethod, callData.CalledMethodStack.Count));
        }

        ///<summary>
        ///Remove all callInfo that added in current method and it's child.
        ///</summary>
        private void ClearCallInfo(List<CallCommandInfo> callInfoList, int callevel)
        {
            for (int i = callInfoList.Count - 1; i >= 0; i--)
            {
                if (callInfoList[i].CallLevel >= callevel)
                {
                    callInfoList.RemoveAt(i);
                }
            }
        }

        ///<summary>
        ///Get position where the call happens.
        ///Returns the found callInfo.
        ///</summary>
        private CallCommandInfo LocateCallInfoByCalledMethod(List<CallCommandInfo> callCommandList, SMethod sMethod)
        {
            for (int i = callCommandList.Count - 1; i >= 0; i--)
            {
                CallCommandInfo callInfo = callCommandList[i];
                if (callInfo.isCalling(sMethod))
                {
                    callCommandList.RemoveAt(i);
                    return callInfo;
                }
            }
            return null;
        }

        /// <summary>
        /// Get CallDataHolder of specified thread.
        /// </summary>
        /// <param name="threadId"></param>
        /// <returns></returns>
        internal CallDataHolder GetThreadCallData(String threadId)
        {
            if (threadCallData.ContainsKey(threadId))
            {
                return threadCallData[threadId];
            }
            else
            {
                CallDataHolder callData = new CallDataHolder();
                System.Object lockWrite = new System.Object();
                lock (lockWrite)
                {
                    threadCallData[threadId] = callData;
                }
                return callData;
            }
        }

        ///// <summary>
        ///// Get information of called method(last one in stack).
        ///// </summary>
        ///// <param name="threadId"></param>
        ///// <returns></returns>
        //internal CalledMethodInfo GetCurrentMethodInfo(String threadId)
        //{
        //    CallDataHolder callData = threadCallData[threadId];
        //    return callData.CalledMethodStack.Peek();
        //}

        internal int Level(String threadId)
        {
            CallDataHolder callData = threadCallData[threadId];
            return callData.CalledMethodStack.Count;
        }
    }
}
