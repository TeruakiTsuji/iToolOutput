﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Reflection;

namespace ITool.Log4Net
{
    class StackTracer
    {
        /// <summary>
        /// Get the line and column number where the exception happened.
        /// We will search from stack of a exception, so need name of 
        /// current method of Application to locate that method in stack.
        /// </summary>
        /// <param name="appModuleName"></param>
        /// <param name="appMethodName"></param>
        /// <param name="ex"></param>
        /// <returns></returns>
        internal static int[] GetExceptionHappenLineNumber(
            String appModuleName, String appMethodName, Exception ex)
        {
            if (ex == null)
            {
                return null;
            }

            StackTrace stackTrace = new StackTrace(ex, true);
            for (int i = 0; i < stackTrace.FrameCount; i++)
            {
                StackFrame stackFrame = stackTrace.GetFrame(i);
                MethodBase methodBase = stackFrame.GetMethod();
                String moduleName = methodBase.DeclaringType.FullName;
                String methodName = methodBase.Name;

                if (moduleName.Equals(appModuleName) && methodName.Equals(appMethodName))
                {
                    return new int[] { stackFrame.GetFileLineNumber(), stackFrame.GetFileColumnNumber() };
                }
            }
            return null;
        }


        /// <summary>
        /// Track the module who is calling the processed method(the one is calling MethodStart()).
        /// If the processed method is first method, return null, otherwise return found caller module.
        /// </summary>
        /// <param name="appModuleName">module name of processed method</param>
        /// <param name="appMethodName">name of processed method</param>
        /// <returns></returns>
        internal static CallCommandInfo TrackCallerModule(String appModuleName, String appMethodName)
        {
            StackTrace stackTrace = new StackTrace(true);
            int index = 0;
            StackFrame stackFrame = null;
            MethodBase methodBase = null;
            //locate method who is calling MethodStart()
            for (; index < stackTrace.FrameCount; index++)
            {
                stackFrame = stackTrace.GetFrame(index);
                methodBase = stackFrame.GetMethod();
                String moduleName = methodBase.DeclaringType.FullName;
                if (moduleName.StartsWith("ITool.Log4Net") == false)
                {
                    //ensure located method is corrent
                    if (moduleName.Equals(appModuleName) == false ||
                        methodBase.Name.Equals(appMethodName) == false)
                    {
                        return null;
                    }
                    break;
                }
            }

            if (index == stackTrace.FrameCount)
            {
                //nou found
                return null;
            }
            else if (index == stackTrace.FrameCount - 1)
            {
                //the processed method is first level
                return null;
            }
            else
            {
                //get caller module
                index++;
                stackFrame = stackTrace.GetFrame(index);
                methodBase = stackFrame.GetMethod();
                return new CallCommandInfo(
                    new SMethod(methodBase.DeclaringType.FullName, methodBase.Name, 0, 0),
                    stackFrame.GetFileLineNumber(), stackFrame.GetFileColumnNumber(), null, 0);
            }

        }

    }
}
