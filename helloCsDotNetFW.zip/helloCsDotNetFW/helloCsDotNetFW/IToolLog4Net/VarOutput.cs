﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;

namespace ITool.Log4Net
{
    class VarOutput
    {
        private static ILog logger = null;

        //format for methodStart : methodLine,methodChar,moduleMethodName,seqNo,line,char,calledModuleMethodName
        private const String fmtMethodStartSub = "{0:D},{1:D},{2:D},{3:G},{4:D},*,{5:D},{6:D}";
        private const String fmtMethodStartCall = "{0:D},{1:D},{2:D},{3:G},{4:D},**,{5:D},{6:D}";
        //format for value : methodLine,methodChar,moduleMethodName,seqNo,line,char,
        private const String fmtValue = "{0:D},{1:D},{2:D},{3:G},{4:D},{5:D},{6:D},";

        //list for saving variables in a group, when last variable is set, all in group will be output together
        private List<String[]> varGroup = new List<String[]>();
        private const int MAX_KEEP_ITEM = 10;

        internal VarOutput(ILog log)
        {
            logger = log;
        }

        ///<summary>
        ///Output call information.
        ///</summary>
        internal void MethodStart(CalledMethodInfo calledMethodInfo, int methodLevel, long logSeqNo)
        {
            SMethod sMethod = calledMethodInfo.CalledMethod;
            String content = null;
            if (calledMethodInfo.CallHappenLineNum == 0)
            {
                //this is a sub method
                content = String.Format(fmtMethodStartSub, methodLevel,
                        sMethod.MethodLineNum, sMethod.MethodCharNum,
                        sMethod.ModuleName + "#" + sMethod.MethodName,
                        logSeqNo, sMethod.MethodLineNum, sMethod.MethodCharNum);
            }
            else
            {
                //this is a called method
                content = String.Format(fmtMethodStartCall, methodLevel,
                        sMethod.MethodLineNum, sMethod.MethodCharNum,
                        sMethod.ModuleName + "#" + sMethod.MethodName,
                        logSeqNo, calledMethodInfo.CallHappenLineNum, calledMethodInfo.CallHappenCharNum);
            }
            logger.Info(content);
        }

        ///<summary>
        ///Output variable's value.
        ///</summary>
        internal void VarValue(SMethod currentMethod, int methodLevel, int lineNumOrg, int charNumOrg,
                String varName, String varValueStr, long logSeqNo, bool isFinal)
        {
            if (isFinal == true || varGroup.Count == MAX_KEEP_ITEM - 1)
            {
                //if this variable is single one or last one in a group, output it or whole group
                StringBuilder sb = new StringBuilder(
                        String.Format(fmtValue, methodLevel,
                                currentMethod.MethodLineNum, currentMethod.MethodCharNum,
                                currentMethod.ModuleName + "#" + currentMethod.MethodName,
                                logSeqNo, lineNumOrg, charNumOrg));
                if (varGroup.Count > 0)
                {
                    foreach (String[] prevVar in varGroup)
                        sb.Append(prevVar[0]).Append('=').Append(prevVar[1]).Append(',');
                }
                sb.Append(varName).Append('=').Append(varValueStr);
                logger.Info(sb.ToString());
                varGroup.Clear();
            }
            else
            {
                //save it, not output
                varGroup.Add(new String[] { varName, varValueStr });
            }

        }
    }
}
