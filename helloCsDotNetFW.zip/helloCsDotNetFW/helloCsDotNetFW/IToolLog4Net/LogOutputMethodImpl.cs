﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;

namespace ITool.Log4Net
{
    class LogOutputMethodImpl : LogOutputBase
    {
        private static ILog logger = null;

        //format for head (method name)	: level,name,startSeq,endSeq,
        private const String fmt1 = "{0:D},{1:G},{2:D},{3:D},";
        //format for body (all steps)	: logKey,line,char,count
        private const String fmt2 = "{0:G},{1:D},{2:D},{3:D},";

        //limit of step logs that can be output in one line of log file, if steps are over the limit, output immediately
        private const int MAX_STEP_PER_LINE = 100;

        public LogOutputMethodImpl(ILog log)
        {
            logger = log;
        }

        internal override void writeVersion(String version)
        {
            logger.Info(version);
        }

        internal override void MethodStart(String threadId, String moduleName, String methodName, int lineNumOrg, int charNumOrg)
        {
            base.MethodStart(threadId, moduleName, methodName, lineNumOrg, charNumOrg);

            CallDataHolder callData = GetThreadCallData(threadId);
            CalledMethodInfo calledMethodInfo = callData.CalledMethodStack.Peek();
            calledMethodInfo.AddStepLog(LK_METHOD_START, lineNumOrg, charNumOrg, SeqNo++);
        }

        internal override void MethodEnd(String threadId, String moduleName, String methodName, int lineNumOrg, int charNumOrg)
        {
            CallDataHolder callData = GetThreadCallData(threadId);
            CalledMethodInfo calledMethodInfo = callData.CalledMethodStack.Peek();

            calledMethodInfo.AddStepLog(LK_METHOD_END, lineNumOrg, charNumOrg, SeqNo++);
            outputLog(calledMethodInfo, callData.CalledMethodStack.Count);
            base.MethodEnd(threadId, moduleName, methodName, lineNumOrg, charNumOrg);
        }

        internal override void ThenStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            saveStepLog(threadId, LK_THEN_START, lineNumOrg, charNumOrg);
        }

        internal override void ElseStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            saveStepLog(threadId, LK_ELSE_START, lineNumOrg, charNumOrg);
        }

        internal override void CycleStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            saveStepLog(threadId, LK_CYCLE_START, lineNumOrg, charNumOrg);
        }

        internal override void CaseStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            saveStepLog(threadId, LK_CASE_START, lineNumOrg, charNumOrg);
        }

        internal override void TryStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            saveStepLog(threadId, LK_TRY_START, lineNumOrg, charNumOrg);
        }

        internal override void CatchStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            saveStepLog(threadId, LK_CATCH_START, lineNumOrg, charNumOrg);
        }

        internal override void FinallyStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            saveStepLog(threadId, LK_FINALLY_START, lineNumOrg, charNumOrg);
        }

        internal override void ExceptionCatched(String threadId, bool forAppTry, int lineNumOrg, int charNumOrg)
        {
            CallDataHolder callData = GetThreadCallData(threadId);
            CalledMethodInfo calledMethodInfo = callData.CalledMethodStack.Peek();
            //Output EXP log when:
            //1.is for app's try, output for every try even is same exception
            //2.is for iTool's try, but there is no app's try to process the exception
            //This case will happedn when there is App's catch who has process the ExceptionCatched,
            //and current one is created by iToolLog's catch.
            String exceptionKey = lineNumOrg.ToString() + charNumOrg.ToString();
            if (forAppTry == true || calledMethodInfo.IsExceptionProcessed(exceptionKey) == false)
            {
                saveStepLog(threadId, LK_EXCEPTION_CATCHED, lineNumOrg, charNumOrg);
                calledMethodInfo.SetExceptionProcessed(exceptionKey);
            }
        }

        ///<summary>
        ///Save a step log into calledMethodInfo, if over limit, output to file as one line.
        ///</summary>
        private void saveStepLog(String threadId, String logKey, int lineNum, int charNum)
        {
            CallDataHolder callData = GetThreadCallData(threadId);
            CalledMethodInfo calledMethodInfo = callData.CalledMethodStack.Peek();

            calledMethodInfo.AddStepLog(logKey, lineNum, charNum, SeqNo++);
            if (calledMethodInfo.GetStepLogCount() >= MAX_STEP_PER_LINE)
            {
                outputLog(calledMethodInfo, callData.CalledMethodStack.Count);
            }
        }

        ///<summary>
        ///Output log of one method.
        ///</summary>
        private void outputLog(CalledMethodInfo calledMethodInfo, int calledMethodCount)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(String.Format(fmt1,
                        calledMethodCount,
                        calledMethodInfo.GetMethodInfoText(),
                        calledMethodInfo.StartSeq, calledMethodInfo.EndSeq));
            foreach (StepLog stepLog in calledMethodInfo.GetStepLogList())
            {
                sb.Append(String.Format(fmt2,
                        stepLog.LogKey, stepLog.LineNum, stepLog.CharNum, stepLog.Count));
            }
            calledMethodInfo.ClearStepLog();
            logger.Info(sb.ToString());
        }


    }
}
