﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using log4net.Repository;
using log4net.Config;
using System.IO;
using System.Reflection;
using System.Diagnostics;
using System.Threading;
using log4net.Core;
using log4net.Repository.Hierarchy;
using log4net.Appender;

namespace ITool.Log4Net
{
    public class StepLogOutput
    {
        public static ILog getILog()
        {
            Console.WriteLine("StepLogOutput:" + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            ILog ret = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            return ret;
        }
    }
    public class MethodLogOutput
    {
        public static ILog getILog()
        {
            Console.WriteLine("MethodLogOutput:" + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            ILog ret = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            return ret;
        }
    }
    public class VarLogOutput
    {
        public static ILog getILog()
        {
            Console.WriteLine("VarLogOutput:" + System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            ILog ret = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            return ret;
        }
    }

    public class IToolLogger
    {
        //private const String CONFIG_FILENAME = "./iToolLog.config";
        private const String FILE_PATH = @".\";
        private const String CONFIG_FILENAME = FILE_PATH + @"iToolLog.config";
        //private const String XML_FILENAME = FILE_PATH + @"iToolLog.xml";

        private const String PARAM_OUTPUT_MODE = "OutputMode";
        private const String PARAM_OUTPUT_VAR_VALUE = "OutputVarValue";
        private const String PARAM_JOB_ID = "JobID";

        private static PropertiesFile config = null;
        private static bool setpModeEnabled   = false;
        private static bool methodModeEnabled = false;
        private static bool varOutputEnabled  = false;

        private static LogOutputStepImpl   stepLogOutput;
        private static LogOutputMethodImpl methodLogOutput;
        private static VarOutput           varLogOutput;

        static IToolLogger()
        {
            try
            {
                config = new PropertiesFile(CONFIG_FILENAME);
                //load configuration
                String outputMode = config.GetValue(PARAM_OUTPUT_MODE);
                if ("Method".ToLower().Equals(outputMode.ToLower()))
                {
                    setpModeEnabled = false;
                    methodModeEnabled = true;
                }
                else if ("Step".ToLower().Equals(outputMode.ToLower()))
                {
                    setpModeEnabled = true;
                    methodModeEnabled = false;
                }
                else
                {
                    //Both or default
                    setpModeEnabled = true;
                    methodModeEnabled = true;
                }
                String outputVarValue = config.GetValue(PARAM_OUTPUT_VAR_VALUE);
                if ("yes".Equals(outputVarValue.ToLower()) || "1".Equals(outputVarValue))
                {
                    varOutputEnabled = true;
                }
                else
                {
                    varOutputEnabled = false;
                }

                String jobId = config.GetValue(PARAM_JOB_ID);

                //String version = "VERSION : Driver-" + ResourceFileManager.getVersion();
                String version = "VERSION : Driver-" + getProductVersion();

                //load log4j configuration
                GlobalContext.Properties[PARAM_JOB_ID] = jobId;
                //XmlConfigurator.Configure(new FileInfo(XML_FILENAME));

                if (setpModeEnabled == true)
                {
                    //ILog stepLogger = LogManager.GetLogger("stepModeLogger");
                    ILog stepLogger = StepLogOutput.getILog();

                    stepLogOutput = new LogOutputStepImpl(stepLogger);
                    stepLogOutput.writeVersion(version);
                }
                if (methodModeEnabled == true)
                {
                    //ILog methodLogger = LogManager.GetLogger("methodModeLogger");
                    ILog methodLogger = MethodLogOutput.getILog();

                    methodLogOutput = new LogOutputMethodImpl(methodLogger);
                    methodLogOutput.writeVersion(version);
                }
                if (varOutputEnabled == true)
                {
                    //ILog varLogger = LogManager.GetLogger("varLogger");
                    ILog varLogger = VarLogOutput.getILog();

                    varLogOutput = new VarOutput(varLogger);
                }

            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine(e.StackTrace);
            }
            catch (IOException e)
            {
                Console.WriteLine(e.StackTrace);
            }
            finally
            {
            }
        }

        ///<summary>
        ///Output log for start of a method.
        ///</summary>
        public static void MethodStart(String moduleName, String methodName, int lineNumOrg, int charNumOrg)
        {
            String threadId = GetCurrentThreadId();
            if (setpModeEnabled == true)
            {
                stepLogOutput.MethodStart(threadId, moduleName, methodName, lineNumOrg, charNumOrg);
            }
            if (methodModeEnabled == true)
            {
                methodLogOutput.MethodStart(threadId, moduleName, methodName, lineNumOrg, charNumOrg);
            }
            if (varOutputEnabled == true)
            {
                //get current method from logOutput
                LogOutputBase logOutput = null;
                if (methodLogOutput != null)
                {
                    logOutput = methodLogOutput;
                }
                else
                {
                    logOutput = stepLogOutput;
                }

                CallDataHolder callData = logOutput.GetThreadCallData(threadId);
                CalledMethodInfo currentMethodInfo = callData.CalledMethodStack.Peek();
                //output call information to varOutput
                varLogOutput.MethodStart(currentMethodInfo, logOutput.Level(threadId), logOutput.SeqNo - 1);
            }

        }


        ///<summary>
        ///Output log for end of a method.
        ///</summary>
        public static void MethodEnd(String moduleName, String methodName, int lineNumOrg, int charNumOrg)
        {
            String threadId = GetCurrentThreadId();
            if (setpModeEnabled == true)
            {
                stepLogOutput.MethodEnd(threadId, moduleName, methodName, lineNumOrg, charNumOrg);
            }
            if (methodModeEnabled == true)
            {
                methodLogOutput.MethodEnd(threadId, moduleName, methodName, lineNumOrg, charNumOrg);
            }
        }

        ///<summary>
        ///Output log for start of THEN block.
        ///</summary>
        public static void ThenStart(int lineNumOrg, int charNumOrg)
        {
            String threadId = GetCurrentThreadId();
            if (setpModeEnabled == true)
            {
                stepLogOutput.ThenStart(threadId, lineNumOrg, charNumOrg);
            }
            if (methodModeEnabled == true)
            {
                methodLogOutput.ThenStart(threadId, lineNumOrg, charNumOrg);
            }
        }

        ///<summary>
        ///Output log for start of ELSE block.
        ///</summary>
        public static void ElseStart(int lineNumOrg, int charNumOrg)
        {
            String threadId = GetCurrentThreadId();
            if (setpModeEnabled == true)
            {
                stepLogOutput.ElseStart(threadId, lineNumOrg, charNumOrg);
            }
            if (methodModeEnabled == true)
            {
                methodLogOutput.ElseStart(threadId, lineNumOrg, charNumOrg);
            }
        }

        ///<summary>
        ///Output log for start of cycle(FOR,WHILE,DO) block.
        ///</summary>
        public static void CycleStart(int lineNumOrg, int charNumOrg)
        {
            String threadId = GetCurrentThreadId();
            if (setpModeEnabled == true)
            {
                stepLogOutput.CycleStart(threadId, lineNumOrg, charNumOrg);
            }
            if (methodModeEnabled == true)
            {
                methodLogOutput.CycleStart(threadId, lineNumOrg, charNumOrg);
            }
        }

        ///<summary>
        ///Output log for start of CASE(in SWITCH) statement.
        ///</summary>
        public static void CaseStart(int lineNumOrg, int charNumOrg)
        {
            String threadId = GetCurrentThreadId();
            if (setpModeEnabled == true)
            {
                stepLogOutput.CaseStart(threadId, lineNumOrg, charNumOrg);
            }
            if (methodModeEnabled == true)
            {
                methodLogOutput.CaseStart(threadId, lineNumOrg, charNumOrg);
            }
        }

        ///<summary>
        ///Output log for start of TRY block.
        ///</summary>
        public static void TryStart(int lineNumOrg, int charNumOrg)
        {
            String threadId = GetCurrentThreadId();
            if (setpModeEnabled == true)
            {
                stepLogOutput.TryStart(threadId, lineNumOrg, charNumOrg);
            }
            if (methodModeEnabled == true)
            {
                methodLogOutput.TryStart(threadId, lineNumOrg, charNumOrg);
            }
        }

        ///<summary>
        ///Output log for start of CATCH block.
        ///</summary>
        public static void CatchStart(int lineNumOrg, int charNumOrg)
        {
            String threadId = GetCurrentThreadId();

            if (setpModeEnabled == true)
            {
                stepLogOutput.CatchStart(threadId, lineNumOrg, charNumOrg);
            }
            if (methodModeEnabled == true)
            {
                methodLogOutput.CatchStart(threadId, lineNumOrg, charNumOrg);
            }
        }

        ///<summary>
        ///Output log for start of FINALLY block.
        ///</summary>
        public static void FinallyStart(int lineNumOrg, int charNumOrg)
        {
            String threadId = GetCurrentThreadId();
            if (setpModeEnabled == true)
            {
                stepLogOutput.FinallyStart(threadId, lineNumOrg, charNumOrg);
            }
            if (methodModeEnabled == true)
            {
                methodLogOutput.FinallyStart(threadId, lineNumOrg, charNumOrg);
            }
        }

        ///<summary>
        ///Add callInfo before a call happens.
        ///</summary>
        public static void BeforeCall(int lineNumOrg, int charNumOrg,
                String calledModuleName, String calledMethodName,
                int calledMethodLineNumOrg, int calledMethodCharNumOrg)
        {
            String threadId = GetCurrentThreadId();
            if (setpModeEnabled == true)
            {
                stepLogOutput.BeforeCall(threadId, lineNumOrg, charNumOrg,
                        calledModuleName, calledMethodName, calledMethodLineNumOrg, calledMethodCharNumOrg);
            }
            if (methodModeEnabled == true)
            {
                methodLogOutput.BeforeCall(threadId, lineNumOrg, charNumOrg,
                        calledModuleName, calledMethodName, calledMethodLineNumOrg, calledMethodCharNumOrg);
            }

            //		if(varOutputEnabled == true) {
            //			//get current method from logOutput
            //			LogOutputBase logOutput = methodLogOutput!=null?methodLogOutput:stepLogOutput;
            //			CalledMethodInfo currentMethodInfo = logOutput.calledMethodStack.peek();
            //			//output call information to varOutput
            //			varLogOutput.beforeCall(currentMethodInfo.CalledMethod, 
            //					lineNumOrg, charNumOrg, calledModuleName, calledMethodName, 
            //					logOutput.seqNo-1);
            //		}
        }

        public static void ExceptionCatched(bool forAppTry, Exception ex)
        {
            if (ex == null)
            {
                return;
            }

            String threadId = GetCurrentThreadId();
            LogOutputBase logOutput = null;
            if (setpModeEnabled == true)
            {
                logOutput = stepLogOutput;
            }
            else
            {
                logOutput = methodLogOutput;
            }
            CallDataHolder callData = logOutput.GetThreadCallData(threadId);
            CalledMethodInfo calledInfo = callData.CalledMethodStack.Peek();

		    //check ExceptionCauseIsThrow flag
            if (callData.ExceptionCauseIsThrow == true)
            {
                //the exception is caused by THROW, the log has been created
                callData.ExceptionCauseIsThrow = false;
            }
            else
            {
                callData.ExceptionCauseIsThrow = false;
                int[] lineColNum = StackTracer.GetExceptionHappenLineNumber(
                    calledInfo.CalledMethod.ModuleName, calledInfo.CalledMethod.MethodName, ex);
                if (lineColNum == null)
                {
                    //can't get exception happen position
                    return;
                }

                if (setpModeEnabled == true)
                {
                    stepLogOutput.ExceptionCatched(threadId, forAppTry, lineColNum[0], lineColNum[1]);
                }
                if (methodModeEnabled == true)
                {
                    methodLogOutput.ExceptionCatched(threadId, forAppTry, lineColNum[0], lineColNum[1]);
                }
            }

        }

        /**
         * Output Exception-Caught log when a THROW statement is executed.
         * @param forAppTry
         * @param ex
         */
        public static void ThrowHappen(int lineNumOrg, int charNumOrg)
        {
            String threadId = GetCurrentThreadId();
            LogOutputBase logOutput = null;
            if (setpModeEnabled == true)
            {
                logOutput = stepLogOutput;
            }
            else
            {
                logOutput = methodLogOutput;
            }
            CallDataHolder callData = logOutput.GetThreadCallData(threadId);
            callData.ExceptionCauseIsThrow = true;

            if (setpModeEnabled == true)
            {
                stepLogOutput.ExceptionCatched(threadId, true, lineNumOrg, charNumOrg);
            }
            if (methodModeEnabled == true)
            {
                methodLogOutput.ExceptionCatched(threadId, true, lineNumOrg, charNumOrg);
            }
        }

        ///<summary>
        ///Output log for variable's value.
        ///</summary>
        public static void VarValue(int lineNumOrg, int charNumOrg, String varName, Object varValue, bool isFinal)
        {
            if (varOutputEnabled == true)
            {
                String threadId = GetCurrentThreadId();
                //get current method from logOutput
                LogOutputBase logOutput = null;
                if (methodLogOutput != null)
                {
                    logOutput = methodLogOutput;
                }
                else
                {
                    logOutput = stepLogOutput;
                }

                CallDataHolder callData = logOutput.GetThreadCallData(threadId);
                CalledMethodInfo currentMethodInfo = callData.CalledMethodStack.Peek();
                //output variable's value to varOutput
                String varValueStr = null;
                if (varValue == null)
                {
                    varValueStr = "null";
                }
                else if (varValue is String)
                {
                    varValueStr = "\"" + replaceLineFeed((String)varValue) + "\"";
                }
                else
                {
                    varValueStr = replaceLineFeed(varValue.ToString());
                }
                varLogOutput.VarValue(
                        currentMethodInfo.CalledMethod, logOutput.Level(threadId),
                        lineNumOrg, charNumOrg, varName, varValueStr,
                        logOutput.SeqNo, isFinal);
            }
        }

        private static String replaceLineFeed(String org)
        {
            return org.Replace("\r\n", "\\r\\n").Replace("\r", "\\r").Replace("\n", "\\n");
        }

        private static String GetCurrentThreadId()
        {
            Process process = Process.GetCurrentProcess();
            return process.Id + "-" + Thread.CurrentThread.ManagedThreadId.ToString();
        }

        private static String getProductVersion()
        {
            String version = Assembly.GetExecutingAssembly().GetName().Version.ToString();
            int idx = version.IndexOf('.');
            idx = version.IndexOf('.', idx + 1);
            return version.Substring(0, idx);
        }
    }
}
