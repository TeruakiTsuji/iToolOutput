﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ITool.Log4Net
{
    class SMethod
    {
        internal String ModuleName = null;
        internal String MethodName = null;
        internal int MethodLineNum = 0;
        internal int MethodCharNum = 0;

        internal SMethod(String moduleName, String methodName, int methodLineNum, int methodCharNum)
        {
            this.ModuleName = moduleName;
            this.MethodName = methodName;
            this.MethodLineNum = methodLineNum;
            this.MethodCharNum = methodCharNum;
        }

        internal bool Equals(String moduleName, String methodName, int methodLineNum, int methodCharNum)
        {
            return this.ModuleName.Equals(moduleName) &&
                    this.MethodName.Equals(methodName) &&
                    this.MethodLineNum == methodLineNum &&
                    this.MethodCharNum == methodCharNum;
        }

        internal bool Equals(SMethod otherMethod)
        {
            return this.ModuleName.Equals(otherMethod.ModuleName) &&
                    this.MethodName.Equals(otherMethod.MethodName) &&
                    this.MethodLineNum == otherMethod.MethodLineNum &&
                    this.MethodCharNum == otherMethod.MethodCharNum;
        }
    }
}
