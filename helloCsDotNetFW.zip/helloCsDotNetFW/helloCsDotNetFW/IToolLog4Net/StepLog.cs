﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ITool.Log4Net
{
    class StepLog
    {

        internal String LogKey;
        internal int LineNum;
        internal int CharNum;
        internal int Count;

        internal StepLog(String logKey, int lineNum, int charNum)
        {
            this.LogKey = logKey;
            this.LineNum = lineNum;
            this.CharNum = charNum;
            this.Count = 1;
        }
    }
}
