﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ITool.Log4Net
{
    class PropertiesFile
    {
        private Dictionary<String, String> valueMap = null;

        public PropertiesFile(String filename)
        {
            valueMap = new Dictionary<String, String>();
            load(filename);
        }

        private void load(String filename)
        {
            StreamReader sr = new StreamReader(filename, Encoding.Default);
            String line;
            while ((line = sr.ReadLine()) != null)
            {
                line = line.Trim();
                if (line.StartsWith("#") || line.StartsWith(";"))
                {
                    continue;
                }
                int idx = line.IndexOf(';');
                if (idx != -1)
                {
                    line = line.Substring(0, idx - 1);
                }
                idx = line.IndexOf('#');
                if (idx != -1)
                {
                    line = line.Substring(0, idx - 1);
                }
                line = line.Trim();
                if (line.Length == 0)
                {
                    continue;
                }

                string[] nv = line.Split('=');
                valueMap.Add(nv[0].Trim(), nv[1].Trim());
            }

            sr.Close();

        }

        public String GetValue(String key)
        {
            if (valueMap.ContainsKey(key))
            {
                return valueMap[key];
            }
            else
            {
                return "";
            }
        }
    }
}
