﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using System.Threading;
using System.Diagnostics;

namespace ITool.Log4Net
{
    class LogOutputStepImpl : LogOutputBase
    {
        private static ILog logger = null;

        //format for log : level,name,startSeq,endSeq,logKey,line,char
        private const String fmt = "{0:D},{1:G},{2:D},{3:G},{4:D},{5:D}";

        public LogOutputStepImpl(ILog log)
        {
            logger = log;
        }

        internal override void writeVersion(String version)
        {
            logger.Info(version);
        }

        internal override void MethodStart(String threadId, String moduleName, String methodName, int lineNumOrg, int charNumOrg)
        {
            base.MethodStart(threadId, moduleName, methodName, lineNumOrg, charNumOrg);

            //format for top method 	: level,                         ,0  ,0 ,moduleName#methodName    ,SEQ,MDS,...
            //format for other method 	: level,callerModule#callerMethod,101,20,calledModule#calledMethod,SEQ,MDS,...
            outputLog(threadId, LK_METHOD_START, lineNumOrg, charNumOrg);
        }

        internal override void MethodEnd(String threadId, String moduleName, String methodName, int lineNumOrg, int charNumOrg)
        {
            outputLog(threadId, LK_METHOD_END, lineNumOrg, charNumOrg);
            base.MethodEnd(threadId, moduleName, methodName, lineNumOrg, charNumOrg);
        }

        internal override void ThenStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            outputLog(threadId, LK_THEN_START, lineNumOrg, charNumOrg);
        }

        internal override void ElseStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            outputLog(threadId, LK_ELSE_START, lineNumOrg, charNumOrg);
        }

        internal override void CycleStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            outputLog(threadId, LK_CYCLE_START, lineNumOrg, charNumOrg);
        }

        internal override void CaseStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            outputLog(threadId, LK_CASE_START, lineNumOrg, charNumOrg);
        }

        internal override void TryStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            outputLog(threadId, LK_TRY_START, lineNumOrg, charNumOrg);
        }

        internal override void CatchStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            outputLog(threadId, LK_CATCH_START, lineNumOrg, charNumOrg);
        }

        internal override void FinallyStart(String threadId, int lineNumOrg, int charNumOrg)
        {
            outputLog(threadId, LK_FINALLY_START, lineNumOrg, charNumOrg);
        }

        internal override void ExceptionCatched(String threadId, bool forAppTry, int lineNumOrg, int charNumOrg)
        {
            CallDataHolder callData = GetThreadCallData(threadId);
            CalledMethodInfo calledMethodInfo = callData.CalledMethodStack.Peek();
            //Output EXP log when:
            //1.is for app's try, output for every try even is same exception
            //2.is for iTool's try, but there is no app's try to process the exception
            //This case will happedn when there is App's catch who has process the ExceptionCatched,
            //and current one is created by iToolLog's catch.
            String exceptionKey = lineNumOrg.ToString() + charNumOrg.ToString();
            if (forAppTry==true || calledMethodInfo.IsExceptionProcessed(exceptionKey) == false)
            {
                outputLog(threadId, LK_EXCEPTION_CATCHED, lineNumOrg, charNumOrg);
                calledMethodInfo.SetExceptionProcessed(exceptionKey);
            }
        }

        ///<summary>
        ///Output log of one step.
        ///</summary>
        private void outputLog(String threadId, String logKey, int lineNum, int charNum)
        {
            CallDataHolder callData = GetThreadCallData(threadId);
            CalledMethodInfo calledMethod = callData.CalledMethodStack.Peek();
            String content = String.Format(fmt,
                            callData.CalledMethodStack.Count,
                            calledMethod.GetMethodInfoText(),
                            SeqNo++,
                            logKey, lineNum, charNum);

            logger.Info(content);
        }
    }
}
