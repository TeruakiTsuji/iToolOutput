﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ITool.Log4Net
{
    class CallCommandInfo
    {
        internal SMethod CallerMethod;
        internal int CallHappenLineNum;
        internal int CallHappenCharNum;
        internal SMethod CalledMethod;
        internal int CallLevel = 0;//Level of first method is 1, CallLevel of call in it is also 1

        internal CallCommandInfo(SMethod callerMethod, int callHappenLineNum, int callHappenCharNum,
                SMethod calledMethod, int callLevel)
        {
            this.CallerMethod = callerMethod;
            this.CallHappenLineNum = callHappenLineNum;
            this.CallHappenCharNum = callHappenCharNum;
            this.CalledMethod = calledMethod;
            this.CallLevel = callLevel;
        }

        internal bool isCalling(SMethod sMethod)
        {
            return this.CalledMethod.Equals(sMethod);
        }
    }
}
