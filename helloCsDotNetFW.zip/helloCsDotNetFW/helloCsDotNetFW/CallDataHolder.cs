﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ITool.Log4Net
{
    class CallDataHolder
    {
        //CallCommandInfo list, every element is information of call statement
        internal List<CallCommandInfo> CallCommandList = new List<CallCommandInfo>();

        //CalledMethodInfo stack, every element is information of called method
        internal Stack<CalledMethodInfo> CalledMethodStack = new Stack<CalledMethodInfo>();

        //flag to indicate if the previous exception is caused by a THROW statement, 
        //it will be set before a THROW by ThrowHappen(), 
        //and will be cleared in following ExceptionCatched(). 
        internal bool ExceptionCauseIsThrow = false;
    }
}
