using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;using ITool.Log4Net;

namespace helloCsDotNetFW
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnEND_Click_1(object sender, EventArgs e)
        {IToolLogger.MethodStart("helloCsDotNetFW.frmMain","btnEND_Click_1",20,9);try {
            Close();}catch(Exception exITLog) {IToolLogger.ExceptionCatched(false,exITLog);throw exITLog;}finally {IToolLogger.MethodEnd("helloCsDotNetFW.frmMain","btnEND_Click_1",23,9);}
        }
    }
}