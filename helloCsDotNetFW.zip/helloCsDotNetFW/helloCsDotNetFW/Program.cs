using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;using ITool.Log4Net;

namespace helloCsDotNetFW
{
    static class Program
    {
        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {IToolLogger.MethodStart("helloCsDotNetFW.Program","Main",14,9);try {
            Boolean fg = true;
            if( fg == true)
            {IToolLogger.ThenStart(19,13);
                Console.WriteLine("fg is true.");
            }
            else
            {IToolLogger.ElseStart(23,13);
                Console.WriteLine("fg is false.");
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmMain());}catch(Exception exITLog) {IToolLogger.ExceptionCatched(false,exITLog);throw exITLog;}finally {IToolLogger.MethodEnd("helloCsDotNetFW.Program","Main",29,9);}
        }
    }
}