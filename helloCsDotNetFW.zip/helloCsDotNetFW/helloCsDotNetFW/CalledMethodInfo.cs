﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ITool.Log4Net
{
    class CalledMethodInfo
    {
        internal SMethod CalledMethod;
        internal SMethod CallerMethod;
        internal int CallHappenLineNum = 0;
        internal int CallHappenCharNum = 0;

        //list of step log for Method mode
        private List<StepLog> stepLogList = null;
        internal long StartSeq = 0;
        internal long EndSeq = 0;

        private HashSet<String> processedExceptionSet = null;

        internal CalledMethodInfo(SMethod calledMethod, SMethod callerMethod, int callHappenLineNum, int callHappenCharNum)
        {
            this.CalledMethod = calledMethod;
            this.CallerMethod = callerMethod;
            this.CallHappenLineNum = callHappenLineNum;
            this.CallHappenCharNum = callHappenCharNum;
            this.stepLogList = new List<StepLog>();
        }
        ///<summary>
        ///Get method information for output.
        ///</summary>
        internal String GetMethodInfoText()
        {
            String callerText = null;
            if (CallerMethod == null)
            {
                callerText = ",0,0";
            }
            else
            {
                callerText = CallerMethod.ModuleName + "#" + CallerMethod.MethodName + "," +
                        Convert.ToString(CallHappenLineNum) + "," + Convert.ToString(CallHappenCharNum);
            }
            return callerText + "," + CalledMethod.ModuleName + "#" + CalledMethod.MethodName;
        }

        ///<summary>
        ///Add log of a step that will be saved in list and used when output.
        ///</summary>
        internal void AddStepLog(String logKey, int lineNum, int charNum, long seqNo)
        {
            if (stepLogList.Count == 0)
            {
                StartSeq = seqNo;
            }
            stepLogList.Add(new StepLog(logKey, lineNum, charNum));
            EndSeq = seqNo;
        }

        internal int GetStepLogCount()
        {
            return this.stepLogList.Count;
        }

        internal List<StepLog> GetStepLogList()
        {
            return this.stepLogList;
        }
        internal void ClearStepLog()
        {
            this.stepLogList.Clear();
        }

        internal bool IsExceptionProcessed(String exceptionKey)
        {
            return processedExceptionSet == null ? false : processedExceptionSet.Contains(exceptionKey);
        }
        internal void SetExceptionProcessed(String exceptionKey)
        {
            if (processedExceptionSet == null)
            {
                processedExceptionSet = new HashSet<String>();
            }
            processedExceptionSet.Add(exceptionKey);
        }
    }
}
