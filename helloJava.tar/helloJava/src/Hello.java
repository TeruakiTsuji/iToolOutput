
public class Hello
{
    public static void main(String[] argv)
    {
        boolean fg = true;
        if( fg == true ){
            System.out.println("fg is true.");
        }
        else{
            System.out.println("fg is false.");
        }
        System.out.println("Hello Java world.");
    }
}