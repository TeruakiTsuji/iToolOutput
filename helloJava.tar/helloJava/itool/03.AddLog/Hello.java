import me.sat.log4j.iToolLogger;
public class Hello
{
    public static void main(String[] argv)
    {iToolLogger.methodStart("Hello","main",4,5);try {
        boolean fg = true;iToolLogger.varValue(7,9,"fg",fg,true);
        if( fg == true ){iToolLogger.thenStart(7,25);
            System.out.println("fg is true.");
        }
        else{iToolLogger.elseStart(10,13);
            System.out.println("fg is false.");
        }
        System.out.println("Hello Java world.");}catch(Exception exITLog) {iToolLogger.exceptionCatched(false,exITLog);throw exITLog;}finally {iToolLogger.methodEnd("Hello","main",14,5);}
    }
}